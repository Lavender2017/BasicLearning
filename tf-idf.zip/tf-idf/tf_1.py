from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf
mnist = input_data.read_data_sets("Mnist_data/",one_hot=True)


#x不是一个特定的值，而是一个占位符placeholder，我们在#TensorFlow运行计算时输入这个值。我们希望能够输入任意数量的#MNIST图像，每一张图展平成784维的向量。

x = tf.placeholder("float", [None, 784])
y_ = tf.placeholder("float", [None,10])
W = tf.Variable(tf.zeros([784,10]))#784个像素点对应784个权值，10个分类每个分类对应一套权值
b = tf.Variable(tf.zeros([10]))

y = tf.nn.softmax(tf.matmul(x,W) + b)  #模型表示，把常数b加到每一行上


cross_entropy = -tf.reduce_sum(y_*tf.log(y))
train_step = tf.train.GradientDescentOptimizer(0.01).minimize(cross_entropy)

# 在运行计算之前，我们需要添加一个操作来初始化我们创建的变量
init = tf.global_variables_initializer()
# 现在我们可以在一个Session里面启动我们的模型，并初始化变量：
sess = tf.Session()
sess.run(init)
# 开始训练模型，1000次
for i in range(1000):
  batch_xs, batch_ys = mnist.train.next_batch(100)
  sess.run(train_step, feed_dict={x: batch_xs, y_: batch_ys})
correct_prediction = tf.equal(tf.argmax(y,1), tf.argmax(y_,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
print(sess.run(accuracy, feed_dict={x: mnist.test.images, y_: mnist.test.labels}))